writeme3.txt로 보내줘
